[![Build Status](https://travis-ci.org/icgc-argo/argo-metadata-schemas.svg?branch=master)](https://travis-ci.org/icgc-argo/argo-metadata-schemas)
## ARGO Metadata Schemas

This repository maintains ARGO metadata schemas.
